
document.addEventListener("DOMContentLoaded", function() {
    const images = document.querySelectorAll('.service img');

    window.addEventListener('scroll', function() {
        images.forEach(function(image, index) {
            const rect = image.getBoundingClientRect();
            const scrollTop = window.pageYOffset || document.documentElement.scrollTop;

            if (rect.top <= window.innerHeight * 0.8 && rect.bottom >= 0) {
                if (index % 2 === 0) {
                    image.classList.add('right-centered'); 
                    image.classList.remove('centered'); 
                } else {
                    image.classList.add('centered'); 
                    image.classList.remove('right-centered'); 
                }
            } else {
                image.classList.remove('centered', 'right-centered'); 
            }
        });
    });

    document.addEventListener("DOMContentLoaded", function() {
         var enquiryLink = document.querySelector('a[href="#enquiry"]');
         enquiryLink.addEventListener("click", function(event) {
             event.preventDefault();
            var enquirySection = document.getElementById('enquiry');
            enquirySection.scrollIntoView({ behavior: 'smooth' });
        });
    });

    document.getElementById('analyze-btn').addEventListener('click', function() {
   
        alert('Analysis process not implemented in this basic example.');
    });
});

    document.addEventListener("DOMContentLoaded", function() {
        var welcomeText = document.getElementById('welcome-text');
        var text = "Hi! Welcome To TourNest Assist";

        function typeWriter(text, i, cb) {
            if (i < text.length) {
                welcomeText.innerHTML += text.charAt(i);
                i++;
                setTimeout(function() {
                    typeWriter(text, i, cb);
                }, 100);
            } else {
                cb();
            }
        }

        typeWriter(text, 0, function() {
         
        });
    });

    document.addEventListener("DOMContentLoaded", function() {
        var welcomeText = document.getElementById('Hi! Welcome To TourNest Assist..');
        var text = "Hi! Welcome To TourNest Assist..";

        function typeWriter(text, i, cb) {
            if (i < text.length) {
                welcomeText.innerHTML += text.charAt(i);
                i++;
                setTimeout(function() {
                    typeWriter(text, i, cb);
                }, 100); 
            } else {
                cb();
            }
        }

        typeWriter(text, 0, function() {
    
        });
    });

